import tkinter as tk
from tkinter import messagebox

# ------------------------------
# Globale Variablen
# ------------------------------
budget = 0.0
budget_label = None

getraenke = {
    "Wasser": 1.00,
    "Cola": 1.50,
    "Fanta": 1.30
}

# ------------------------------
# Funktionen
# ------------------------------
def addiere(betrag):
    global budget
    budget += betrag
    budget_label.config(text=f"Budget: {budget:.2f} €")

def kaufe_getraenk(name):
    global budget
    preis = getraenke[name]
    if budget >= preis:
        budget -= preis
        budget_label.config(text=f"Budget: {budget:.2f} €")
        messagebox.showinfo("Erfolg", f"{name} wurde gekauft!")
    else:
        messagebox.showwarning("Fehler", "Nicht genug Budget!")

def zuruecksetzen():
    global budget
    budget = 0.0
    budget_label.config(text=f"Budget: {budget:.2f} €")

# ------------------------------
# GUI-Setup
# ------------------------------
fenster = tk.Tk()
fenster.title("Beispiel-GUI: Getränkeautomat")

budget_label = tk.Label(fenster, anchor="w", width=20, text=f"Budget: {budget:.2f} €")
budget_label.grid(row=0, column=0, columnspan=3, pady=5)

# Geld hinzufügen Buttons
tk.Button(fenster, text="0,5 €", command=lambda: addiere(0.5)).grid(row=1, column=0, padx=5, pady=5)
tk.Button(fenster, text="1 €", command=lambda: addiere(1)).grid(row=1, column=1, padx=5, pady=5)
tk.Button(fenster, text="2 €", command=lambda: addiere(2)).grid(row=1, column=2, padx=5, pady=5)

# Zurücksetzen Button
tk.Button(fenster, text="Zurücksetzen", command=zuruecksetzen).grid(row=2, column=0, columnspan=3, pady=5)

# Getränke Buttons
tk.Button(fenster, text="Wasser (1.00 €)", command=lambda: kaufe_getraenk("Wasser")).grid(row=3, column=0, columnspan=3, pady=2)
tk.Button(fenster, text="Cola (1.50 €)", command=lambda: kaufe_getraenk("Cola")).grid(row=4, column=0, columnspan=3, pady=2)
tk.Button(fenster, text="Fanta (1.30 €)", command=lambda: kaufe_getraenk("Fanta")).grid(row=5, column=0, columnspan=3, pady=2)

fenster.mainloop()
