# Getränkeautomat mit GUI in Python
# Mit ausführlichen Kommentaren und Zurücksetzen-Button

import tkinter as tk  # Das GUI-Toolkit für Fenster, Buttons usw.
from tkinter import messagebox  # Für Pop-up-Nachrichten (Info / Warnung)
from PIL import Image, ImageTk  # Für das Laden und Anzeigen von Bildern in tkinter

# Hauptklasse für den Getränkeautomaten
class GetraenkeAutomat:
    def __init__(self, master):
        self.master = master
        self.master.title("Getränkeautomat")  # Fenstertitel setzen

        self.budget = 0.0  # Anfangsbudget: 0 Euro

        # Getränke und ihre Preise definieren (in einem Dictionary)
        self.getraenke = {
            "Wasser": 1.00,
            "Cola": 1.50,
            "Fanta": 1.30
        }

        # Benutzeroberfläche erstellen
        self.create_widgets()

    def create_widgets(self):
        # ---------- Hauptlayout ----------
        # Frame für das gesamte Layout (Bild + Steuerung)
        hauptrahmen = tk.Frame(self.master)
        hauptrahmen.pack(padx=10, pady=10)  # Abstand zum Fensterrand

        # ---------- Linke Seite: Bild ----------
        # Bild aus Datei laden (muss im selben Ordner wie das Skript sein)
        bild = Image.open("bild.png")
        bild = bild.resize((100, 100))  # Optional: Bildgröße anpassen
        self.tk_bild = ImageTk.PhotoImage(bild)  # Umwandlung für tkinter

        # Label mit Bild erstellen, links oben platzieren
        bild_label = tk.Label(hauptrahmen, image=self.tk_bild)
        bild_label.grid(row=0, column=0, rowspan=4, padx=10, pady=10, sticky="n")

        # ---------- Rechte Seite: Steuerung ----------
        # Neuer Frame für alle Steuerelemente rechts vom Bild
        rechte_seite = tk.Frame(hauptrahmen)
        rechte_seite.grid(row=0, column=1, sticky="nw")

        # ---------- Budgetanzeige ----------
        # Zeigt das aktuelle Budget an
        self.budget_label = tk.Label(rechte_seite, text=f"Budget: {self.budget:.2f} €")
        self.budget_label.pack(pady=5)

        # ---------- Geld einwerfen ----------
        # Frame für die Geld-Buttons
        geldrahmen = tk.Frame(rechte_seite)
        tk.Label(geldrahmen, text="Geld einwerfen:").pack(side=tk.LEFT)

        # Buttons für verschiedene Geldbeträge (0.50 €, 1 €, 2 €)
        for betrag in [0.5, 1, 2]:
            # Jeder Button fügt Betrag dem Budget hinzu
            tk.Button(geldrahmen, text=f"{betrag} €", command=lambda b=betrag: self.geld_hinzufuegen(b)).pack(side=tk.LEFT)

        geldrahmen.pack(pady=5)

        # ---------- Zurücksetzen-Button ----------
        # Kleiner Button, um das Budget wieder auf 0.00 € zu setzen
        reset_button = tk.Button(rechte_seite, text="Zurücksetzen", command=self.zuruecksetzen)
        reset_button.pack(pady=5)

        # ---------- Getränkeauswahl ----------
        # Rahmen mit Buttons für jedes Getränk
        self.getraenkrahmen = tk.LabelFrame(rechte_seite, text="Getränke")

        # Für jedes Getränk einen Button erstellen
        for name, preis in self.getraenke.items():
            # Beim Klick wird geprüft, ob man genug Geld hat
            tk.Button(self.getraenkrahmen, text=f"{name} ({preis:.2f} €)", command=lambda g=name: self.kaufe_getraenk(g)).pack(pady=2)

        self.getraenkrahmen.pack(pady=10)

    # ---------- Geld hinzufügen Funktion ----------
    def geld_hinzufuegen(self, betrag):
        self.budget += betrag  # Budget erhöhen
        self.budget_label.config(text=f"Budget: {self.budget:.2f} €")  # Anzeige aktualisieren

    # ---------- Getränk kaufen Funktion ----------
    def kaufe_getraenk(self, name):
        preis = self.getraenke[name]  # Preis auslesen
        if self.budget >= preis:
            self.budget -= preis  # Preis abziehen
            self.budget_label.config(text=f"Budget: {self.budget:.2f} €")  # Anzeige aktualisieren
            messagebox.showinfo("Erfolg", f"{name} wurde gekauft!")  # Erfolg anzeigen
        else:
            messagebox.showwarning("Fehler", "Nicht genug Budget!")  # Warnung anzeigen

    # ---------- Zurücksetzen Funktion ----------
    def zuruecksetzen(self):
        self.budget = 0.0  # Budget auf null setzen
        self.budget_label.config(text=f"Budget: {self.budget:.2f} €")  # Anzeige aktualisieren

# ---------- Start des Programms ----------
if __name__ == "__main__":
    root = tk.Tk()  # Fenster erstellen
    app = GetraenkeAutomat(root)  # Objekt der Klasse erzeugen
    root.mainloop()  # GUI starten (Hauptschleife)

# Vorgehensweise:
# - GUI mit tkinter erstellt.
# - Bild ("bild.png") wird links angezeigt.
# - Budget kann über Buttons erhöht werden (0.5, 1, 2 Euro).
# - Getränk kann gekauft werden, wenn genug Budget vorhanden ist.
# - Pop-up zeigt Erfolg oder Fehler beim Kauf an.
# - Zusätzlich gibt es jetzt einen "Zurücksetzen"-Button, der das Budget wieder auf 0 setzt.
# - Layout ist übersichtlich mit grid() strukturiert (Bild links, Buttons rechts).

