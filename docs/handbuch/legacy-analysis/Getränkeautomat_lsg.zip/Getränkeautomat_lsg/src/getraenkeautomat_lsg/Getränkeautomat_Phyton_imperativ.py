# ------------------------------
# Modul-Importe
# ------------------------------
import tkinter as tk  # Das Standard-GUI-Toolkit von Python
from tkinter import messagebox  # Für Pop-up-Nachrichten (Info/Warnung)
from PIL import Image, ImageTk  # Zum Laden und Anzeigen von Bildern im tkinter-Format

# ------------------------------
# Globale Variablen (Zustand)
# ------------------------------
budget = 0.0  # Startwert des Budgets in Euro
budget_label = None  # Referenz auf die GUI-Anzeige des Budgets
getraenke = {  # Getränkeauswahl mit Preisen
    "Wasser": 1.00,
    "Cola": 1.50,
    "Fanta": 1.30
}

# ------------------------------
# Funktion zum Hinzufügen von Geld
# ------------------------------
def geld_hinzufuegen(betrag):
    global budget  # Zugriff auf die globale Variable
    budget += betrag  # Erhöhe das Budget um den eingegebenen Betrag
    # Aktualisiere die Anzeige des Budgets in der GUI
    budget_label.config(text=f"Budget: {budget:.2f} €")

# ------------------------------
# Funktion zum Kauf eines Getränks
# ------------------------------
def kaufe_getraenk(name):
    global budget  # Zugriff auf das globale Budget
    preis = getraenke[name]  # Preis des gewählten Getränks aus dem Dictionary lesen
    if budget >= preis:  # Prüfen, ob genügend Geld vorhanden ist
        budget -= preis  # Preis vom Budget abziehen
        # Aktualisiere Budgetanzeige
        budget_label.config(text=f"Budget: {budget:.2f} €")
        # Erfolgsmeldung anzeigen
        messagebox.showinfo("Erfolg", f"{name} wurde gekauft!")
    else:
        # Fehlermeldung bei zu geringem Budget
        messagebox.showwarning("Fehler", "Nicht genug Budget!")

# ------------------------------
# Funktion zum Zurücksetzen des Budgets
# ------------------------------
def zuruecksetzen():
    global budget  # Zugriff auf das globale Budget
    budget = 0.0  # Budget auf null setzen
    # Anzeige in der GUI aktualisieren
    budget_label.config(text=f"Budget: {budget:.2f} €")

# ------------------------------
# Funktion zur Erstellung der gesamten GUI
# ------------------------------
def erstelle_gui():
    global budget_label  # Damit das Label von anderen Funktionen geändert werden kann

    root = tk.Tk()  # Hauptfenster erzeugen
    root.title("Getränkeautomat")  # Titel des Fensters setzen

    hauptrahmen = tk.Frame(root)  # Haupt-Layout-Container
    hauptrahmen.pack(padx=10, pady=10)  # Abstand zum Fensterrand

    # ------------------------------
    # Bild (linke Seite)
    # ------------------------------
    bild = Image.open("bild.png")  # Bilddatei öffnen (im gleichen Ordner wie das Skript)
    bild = bild.resize((100, 100))  # Bildgröße anpassen
    tk_bild = ImageTk.PhotoImage(bild)  # In tkinter-kompatibles Format umwandeln

    bild_label = tk.Label(hauptrahmen, image=tk_bild)  # Label mit Bild
    bild_label.image = tk_bild  # WICHTIG: Referenz behalten, sonst wird Bild nicht angezeigt
    bild_label.grid(row=0, column=0, rowspan=4, padx=10, pady=10, sticky="n")  # In der linken Spalte positionieren

    # ------------------------------
    # Rechte Seite mit Steuerelementen
    # ------------------------------
    rechte_seite = tk.Frame(hauptrahmen)  # Container für Steuerelemente rechts neben dem Bild
    rechte_seite.grid(row=0, column=1, sticky="nw")  # Oben rechts ausrichten

    # ------------------------------
    # Anzeige des Budgets
    # ------------------------------
    budget_label = tk.Label(rechte_seite, text=f"Budget: {budget:.2f} €")  # Zeigt aktuelles Budget an
    budget_label.pack(pady=5)

    # ------------------------------
    # Geld einwerfen: Buttons für 0.5 €, 1 €, 2 €
    # ------------------------------
    geldrahmen = tk.Frame(rechte_seite)  # Untercontainer für Geld-Buttons
    tk.Label(geldrahmen, text="Geld einwerfen:").pack(side=tk.LEFT)  # Beschriftung links

    for betrag in [0.5, 1, 2]:  # Für jeden Betrag einen Button
        # Jeder Button ruft geld_hinzufuegen mit dem entsprechenden Wert auf
        tk.Button(geldrahmen, text=f"{betrag} €", command=lambda b=betrag: geld_hinzufuegen(b)).pack(side=tk.LEFT)

    geldrahmen.pack(pady=5)  # Rahmen mit Buttons einfügen

    # ------------------------------
    # Zurücksetzen-Button
    # ------------------------------
    tk.Button(rechte_seite, text="Zurücksetzen", command=zuruecksetzen).pack(pady=5)

    # ------------------------------
    # Getränkeauswahl (Buttons mit Getränken)
    # ------------------------------
    getraenkrahmen = tk.LabelFrame(rechte_seite, text="Getränke")  # Rahmen mit Überschrift "Getränke"

    for name, preis in getraenke.items():  # Für jedes Getränk...
        # ...einen Button mit Name und Preis erzeugen
        tk.Button(getraenkrahmen, text=f"{name} ({preis:.2f} €)", command=lambda g=name: kaufe_getraenk(g)).pack(pady=2)

    getraenkrahmen.pack(pady=10)  # Getränke-Rahmen anzeigen

    # ------------------------------
    # GUI starten
    # ------------------------------
    root.mainloop()  # GUI-Ereignisschleife starten (Fenster anzeigen)

# ------------------------------
# Hauptprogramm mit Methodenaufruf 
# für die GUI
# ------------------------------

if __name__ == "__main__":
    erstelle_gui()  # GUI aufbauen und starten
