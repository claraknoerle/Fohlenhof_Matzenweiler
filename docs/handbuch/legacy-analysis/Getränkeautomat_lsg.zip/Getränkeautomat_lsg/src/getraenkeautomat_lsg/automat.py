import tkinter as tk
from PIL import Image, ImageTk

def erstelle_gui():
    root = tk.Tk()
    root.title("Getränkeautomat")

    hauptrahmen = tk.Frame(root)
    hauptrahmen.pack(padx=10, pady=10)

    # Bild laden und anzeigen
    bild = Image.open("bild.png")
    bild = bild.resize((100, 100))
    tk_bild = ImageTk.PhotoImage(bild)
    bild_label = tk.Label(hauptrahmen, image=tk_bild)
    bild_label.image = tk_bild
    bild_label.grid(row=0, column=0, rowspan=4, padx=10, pady=10, sticky="n")

    root.mainloop()

#Methodenaufruf
erstelle_gui()
