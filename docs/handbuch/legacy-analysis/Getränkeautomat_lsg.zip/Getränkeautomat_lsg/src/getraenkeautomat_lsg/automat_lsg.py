import tkinter as tk
from PIL import Image, ImageTk

# Importiert das Modul 'messagebox' aus tkinter,
# um Info- und Warnmeldungen in einem kleinen Fenster (Pop-up) anzuzeigen.
from tkinter import messagebox

budget = 0.0

# Ein Dictionary mit Getränken und ihren Preisen in Euro.
# Schlüssel = Getränkename, Wert = Preis in Euro          
getraenke = {
    "Wasser": 1.00,
    "Cola": 1.50,
    "Fanta": 1.30
}

def zuruecksetzen():
    global budget
    budget = 0.0
    budget_label.config(text=f"Budget: {budget:.2f} €")

# Definiert eine Funktion mit dem Namen 'kaufe_getraenk'.
# Der Parameter 'name' gibt an, welches Getränk gekauft werden soll.
def kaufe_getraenk(name):
    # Gibt an, dass auf die globale Variable 'budget' zugegriffen wird,
    # damit die Funktion den Wert verändern darf.
    global budget
    # Liest aus dem Dictionary 'getraenke' den Preis des gewählten Getränks.
    # Beispiel: Wenn name="Cola", wird preis=1.50
    preis = getraenke[name]
    
    # Prüft, ob genug Geld (budget) vorhanden ist, um das Getränk zu kaufen.
     # Wenn ja, wird der Preis vom Budget abgezogen (neues Restbudget).
    if budget >= preis:
        budget -= preis
        
        # Das Label in der Benutzeroberfläche wird aktualisiert,
        # damit der Benutzer den neuen Budgetstand sieht.
        # .2f sorgt für die Anzeige mit zwei Nachkommastellen.
        budget_label.config(text=f"Budget: {budget:.2f} €")

        # Zeigt ein Info-Pop-up an, das den erfolgreichen Kauf bestätigt.
        # Beispiel: "Cola wurde gekauft!"
        messagebox.showinfo("Erfolg", f"{name} wurde gekauft!")
    # Wenn das Budget NICHT ausreicht:
    else:
        # Zeigt ein Warn-Pop-up an, dass der Kauf nicht möglich ist.
        # z. B. weil nicht genug Geld vorhanden ist.
        messagebox.showwarning("Fehler", "Nicht genug Budget!")

def geld_hinzufuegen(betrag):
    global budget
    budget += betrag

    budget_label.config(text=f"Budget: {budget:.2f} €")

def erstelle_gui():
    root = tk.Tk()
    root.title("Getränkeautomat")

    hauptrahmen = tk.Frame(root)
    hauptrahmen.pack(padx=10, pady=10)

    # Bild laden und anzeigen
    bild = Image.open("bild.png")
    bild = bild.resize((100, 100))
    tk_bild = ImageTk.PhotoImage(bild)
    bild_label = tk.Label(hauptrahmen, image=tk_bild)
    bild_label.image = tk_bild
    bild_label.grid(row=0, column=0, rowspan=4, padx=10, pady=10, sticky="n")

    # Rechte Seite
    rechte_seite = tk.Frame(hauptrahmen)
    rechte_seite.grid(row=0, column=1, sticky="nw")

    # Budget-Anzeige
    global budget_label
    budget_label = tk.Label(rechte_seite, text=f"Budget: {budget:.2f} €")
    budget_label.pack(pady=5)

    # Geld einwerfen
    geldrahmen = tk.Frame(rechte_seite)
    tk.Label(geldrahmen, text="Geld einwerfen:").pack(side=tk.LEFT)
    for betrag in [0.5, 1, 2]:
        tk.Button(geldrahmen, text=f"{betrag} €", command=lambda b=betrag: geld_hinzufuegen(b)).pack(side=tk.LEFT)
    geldrahmen.pack(pady=5)
    
    # Getränkeauswahl
    getraenkrahmen = tk.LabelFrame(rechte_seite, text="Getränke")
    for name, preis in getraenke.items():
        tk.Button(getraenkrahmen, text=f"{name} ({preis:.2f} €)", command=lambda g=name: kaufe_getraenk(g)).pack(pady=2)
    getraenkrahmen.pack(pady=10)

    tk.Button(rechte_seite, text="Zurücksetzen", command=zuruecksetzen).pack(pady=5)
    
    root.mainloop()

#Methodenaufruf
erstelle_gui()

